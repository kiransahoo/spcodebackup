import React, { useState, useEffect, useRef } from 'react';
import { 
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer 
} from 'recharts';
import { 
  Bold, 
  Italic, 
  List, 
  AlignLeft, 
  AlignCenter, 
  AlignRight,
  Link2,
  Video,
  Type,
  Heading1,
  Heading2,
  Undo,
  Redo,
  ListOrdered,
  BarChart3,
  PlusCircle,
  Table2,
  TableProperties
} from 'lucide-react';

const App = () => {
  const [salesData, setSalesData] = useState([]);
  const [videoLinks, setVideoLinks] = useState([]);
  const [editorContent, setEditorContent] = useState('');
  const [embeddedCharts, setEmbeddedCharts] = useState([]);
  const [selectedRange, setSelectedRange] = useState(null);
  const editorRef = useRef(null);
  const [showChartMenu, setShowChartMenu] = useState(false);
  const [showVideoMenu, setShowVideoMenu] = useState(false);
  const [showTableMenu, setShowTableMenu] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setIsLoading(true);
        const response = await fetch('http://localhost:8080/api/data');
        const data = await response.json();
        setSalesData(data);
        updateExistingTables(data);
      } catch (error) {
        console.error('Error fetching data:', error);
      } finally {
        setIsLoading(false);
      }
    };

    const fetchVideoLinks = async () => {
      try {
        const response = await fetch('http://localhost:8080/api/videos');
        const data = await response.json();
        setVideoLinks(data);
      } catch (error) {
        console.error('Error fetching video links:', error);
      }
    };

    fetchData();
    fetchVideoLinks();
    const interval = setInterval(fetchData, 5000);

    return () => clearInterval(interval);
  }, []);

  const updateExistingTables = (newData) => {
    if (!editorRef.current) return;

    const tables = editorRef.current.querySelectorAll('.sales-data-table');
    tables.forEach(table => {
      const tbody = table.querySelector('tbody');
      if (tbody) {
        tbody.innerHTML = newData.map(row => `
          <tr>
            <td class="border border-gray-200 px-4 py-2">${row.product}</td>
            <td class="border border-gray-200 px-4 py-2">$${Number(row.revenue).toFixed(2)}</td>
            <td class="border border-gray-200 px-4 py-2">${row.quantity}</td>
            <td class="border border-gray-200 px-4 py-2">${new Date(row.timestamp).toLocaleString()}</td>
          </tr>
        `).join('');

        // Add highlight animation to updated rows
        const rows = tbody.querySelectorAll('tr');
        rows.forEach(row => {
          row.classList.add('updated');
          setTimeout(() => row.classList.remove('updated'), 1000);
        });
      }
    });
  };

  const saveSelection = () => {
    const selection = window.getSelection();
    if (selection.rangeCount > 0) {
      setSelectedRange(selection.getRangeAt(0));
    }
  };

  const restoreSelection = () => {
    if (selectedRange && editorRef.current) {
      const selection = window.getSelection();
      selection.removeAllRanges();
      selection.addRange(selectedRange);
      editorRef.current.focus();
    }
  };

  const execCommand = (command, value = null) => {
    document.execCommand(command, false, value);
    editorRef.current?.focus();
  };

  const insertChart = () => {
    const chartId = Date.now();
    const newChart = {
      id: chartId,
      position: editorContent.length
    };
    
    setEmbeddedCharts([...embeddedCharts, newChart]);
    setShowChartMenu(false);
    
    // Add a line break after chart insertion
    setTimeout(() => {
      execCommand('insertHTML', '<div><br></div>');
    }, 0);
  };

  const insertVideo = (videoUrl) => {
    restoreSelection();
    const videoEmbed = `
      <div class="video-container my-8">
        <div class="relative w-full pt-[56.25%] border rounded-lg overflow-hidden bg-white">
          <iframe 
            src="${videoUrl}"
            class="absolute top-0 left-0 w-full h-full"
            frameborder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowfullscreen
          ></iframe>
        </div>
      </div>
      <div><br></div>
    `;
    
    execCommand('insertHTML', videoEmbed);
    setShowVideoMenu(false);
  };

  const insertTable = () => {
    if (!salesData?.length) return;
    
    restoreSelection();
    const tableHTML = `
      <div class="table-wrapper my-8">
        <table class="sales-data-table w-full border-collapse border border-gray-200">
          <thead>
            <tr class="bg-gray-50">
              <th class="border border-gray-200 px-4 py-2 text-left">Product</th>
              <th class="border border-gray-200 px-4 py-2 text-left">Revenue</th>
              <th class="border border-gray-200 px-4 py-2 text-left">Quantity</th>
              <th class="border border-gray-200 px-4 py-2 text-left">Timestamp</th>
            </tr>
          </thead>
          <tbody>
            ${salesData.map(row => `
              <tr>
                <td class="border border-gray-200 px-4 py-2">${row.product}</td>
                <td class="border border-gray-200 px-4 py-2">$${Number(row.revenue).toFixed(2)}</td>
                <td class="border border-gray-200 px-4 py-2">${row.quantity}</td>
                <td class="border border-gray-200 px-4 py-2">${new Date(row.timestamp).toLocaleString()}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
      <div><br></div>
    `;

    execCommand('insertHTML', tableHTML);
    setShowTableMenu(false);
  };

  const SalesChart = () => (
    <div className="chart-container my-4 border rounded-lg p-4 bg-white" style={{ height: '300px' }}>
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={salesData}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="product" />
          <YAxis yAxisId="left" orientation="left" stroke="#8884d8" />
          <YAxis yAxisId="right" orientation="right" stroke="#82ca9d" />
          <Tooltip />
          <Legend />
          <Line 
            yAxisId="left" 
            type="monotone" 
            dataKey="revenue" 
            stroke="#8884d8" 
            name="Revenue ($)" 
          />
          <Line 
            yAxisId="right" 
            type="monotone" 
            dataKey="quantity" 
            stroke="#82ca9d" 
            name="Quantity" 
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );

  const EditorContent = () => (
    <div>
      {embeddedCharts.map((chart, index) => (
        <React.Fragment key={chart.id}>
          {index > 0 && <div className="my-4" />}
          <SalesChart />
        </React.Fragment>
      ))}
    </div>
  );

  const ToolbarButton = ({ onClick, children, active = false }) => (
    <button
      onClick={onClick}
      className={`p-2 hover:bg-gray-100 rounded-md border border-gray-200 inline-flex items-center justify-center transition-colors ${
        active ? 'bg-gray-100' : ''
      }`}
    >
      {children}
    </button>
  );

  const DropdownMenu = ({ show, onClose, children }) => {
    if (!show) return null;

    return (
      <div className="absolute mt-1 bg-white border rounded-md shadow-lg z-10 p-2">
        {children}
      </div>
    );
  };

  const Toolbar = () => (
    <div className="relative flex flex-wrap gap-2 p-2 bg-gray-50 rounded-md border-b">
      <div className="flex gap-1 items-center">
        <ToolbarButton onClick={() => execCommand('formatBlock', '<h1>')}>
          <Heading1 className="h-4 w-4" />
        </ToolbarButton>
        <ToolbarButton onClick={() => execCommand('formatBlock', '<h2>')}>
          <Heading2 className="h-4 w-4" />
        </ToolbarButton>
        <ToolbarButton onClick={() => execCommand('formatBlock', '<p>')}>
          <Type className="h-4 w-4" />
        </ToolbarButton>
      </div>

      <div className="w-px h-6 bg-gray-300" />

      <div className="flex gap-1 items-center">
        <ToolbarButton onClick={() => execCommand('bold')}>
          <Bold className="h-4 w-4" />
        </ToolbarButton>
        <ToolbarButton onClick={() => execCommand('italic')}>
          <Italic className="h-4 w-4" />
        </ToolbarButton>
        <ToolbarButton onClick={() => execCommand('insertOrderedList')}>
          <ListOrdered className="h-4 w-4" />
        </ToolbarButton>
        <ToolbarButton onClick={() => execCommand('insertUnorderedList')}>
          <List className="h-4 w-4" />
        </ToolbarButton>
      </div>

      <div className="w-px h-6 bg-gray-300" />

      <div className="flex gap-1 items-center">
        <ToolbarButton onClick={() => execCommand('justifyLeft')}>
          <AlignLeft className="h-4 w-4" />
        </ToolbarButton>
        <ToolbarButton onClick={() => execCommand('justifyCenter')}>
          <AlignCenter className="h-4 w-4" />
        </ToolbarButton>
        <ToolbarButton onClick={() => execCommand('justifyRight')}>
          <AlignRight className="h-4 w-4" />
        </ToolbarButton>
      </div>

      <div className="w-px h-6 bg-gray-300" />

      <div className="relative">
        <ToolbarButton 
          onClick={() => setShowTableMenu(!showTableMenu)}
          active={showTableMenu}
        >
          <TableProperties className="h-4 w-4" />
        </ToolbarButton>
        <DropdownMenu show={showTableMenu} onClose={() => setShowTableMenu(false)}>
          <button
            onClick={insertTable}
            className="flex items-center gap-2 px-3 py-2 hover:bg-gray-100 rounded-md w-full"
          >
            <Table2 className="h-4 w-4" />
            Insert Sales Table
          </button>
        </DropdownMenu>
      </div>

      <div className="relative">
        <ToolbarButton 
          onClick={() => setShowChartMenu(!showChartMenu)}
          active={showChartMenu}
        >
          <BarChart3 className="h-4 w-4" />
        </ToolbarButton>
        <DropdownMenu show={showChartMenu} onClose={() => setShowChartMenu(false)}>
          <button
            onClick={insertChart}
            className="flex items-center gap-2 px-3 py-2 hover:bg-gray-100 rounded-md w-full"
          >
            <PlusCircle className="h-4 w-4" />
            Insert Sales Chart
          </button>
        </DropdownMenu>
      </div>

      <div className="relative">
        <ToolbarButton 
          onClick={() => setShowVideoMenu(!showVideoMenu)}
          active={showVideoMenu}
        >
          <Video className="h-4 w-4" />
        </ToolbarButton>
        <DropdownMenu show={showVideoMenu} onClose={() => setShowVideoMenu(false)}>
          {videoLinks.map((video, index) => (
            <button
              key={index}
              onClick={() => insertVideo(video.url)}
              className="flex items-center gap-2 px-3 py-2 hover:bg-gray-100 rounded-md w-full text-left"
            >
              <Video className="h-4 w-4" />
              {video.title}
            </button>
          ))}
        </DropdownMenu>
      </div>
    </div>
  );

  return (
    <div className="max-w-7xl mx-auto p-4">
      <div className="bg-white rounded-lg border shadow-sm">
        <div className="p-6 border-b">
          <h3 className="text-2xl font-semibold">Rich Text Editor</h3>
        </div>
        <div className="p-6 space-y-4">
          <Toolbar />
          
          <div className="relative">
            {isLoading && (
              <div className="loading-overlay">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
              </div>
            )}
            <div
              ref={editorRef}
              className="min-h-[600px] max-h-[800px] overflow-y-auto p-4 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 prose prose-sm max-w-none bg-white"
              contentEditable
              onInput={(e) => setEditorContent(e.currentTarget.innerHTML)}
              onMouseUp={saveSelection}
              onKeyUp={saveSelection}
              onFocus={saveSelection}
            />
            <EditorContent />
          </div>
        </div>
      </div>
    </div>
  );
};

export default App;