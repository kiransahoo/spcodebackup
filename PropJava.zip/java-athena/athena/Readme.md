# Amazon Athena Java code examples

Java code for athena connector.

use the CFN template under cfn dir  to spin up athena resources with example data from amazon 

