package com.spglobal.prop.auth;

//import com.amazonaws.services.cognitoidentity.AmazonCognitoIdentityClient;
import software.amazon.awssdk.auth.credentials.AwsCredentialsProvider;
import software.amazon.awssdk.auth.credentials.AwsSessionCredentials;
import software.amazon.awssdk.auth.credentials.ProfileCredentialsProvider;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.core.ResponseBytes;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.cognitoidentity.CognitoIdentityClient;
import software.amazon.awssdk.services.cognitoidentity.model.GetCredentialsForIdentityRequest;
import software.amazon.awssdk.services.cognitoidentity.model.GetCredentialsForIdentityResponse;
import software.amazon.awssdk.services.cognitoidentity.model.GetIdRequest;
import software.amazon.awssdk.services.cognitoidentity.model.GetIdResponse;
import software.amazon.awssdk.services.cognitoidentityprovider.CognitoIdentityProviderClient;
import software.amazon.awssdk.services.cognitoidentityprovider.model.AdminInitiateAuthRequest;
import software.amazon.awssdk.services.cognitoidentityprovider.model.AdminInitiateAuthResponse;
import software.amazon.awssdk.services.cognitoidentityprovider.model.AuthFlowType;
import software.amazon.awssdk.services.cognitoidentityprovider.model.AuthenticationResultType;

import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.GetObjectRequest;
import software.amazon.awssdk.services.s3.model.ListObjectsRequest;
import software.amazon.awssdk.services.s3.model.S3Exception;
import software.amazon.awssdk.services.s3.model.GetObjectResponse;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import java.util.HashMap;
import java.util.Map;

/**
 * Java code that enables abac using cognito and IAM, please replace hardocoded(****) values with cognito settings before executing this code. This is a test code and is not meant to be prod ready
 */
public class PropTenantAccess {

    public static void main (String[] args)
    {
        try {
            Map<String,String> authParameters = new HashMap<>();
            Map<String,String> idparams = new HashMap<>();
            authParameters.put("USERNAME", "****");
            authParameters.put("PASSWORD", "****");

            AdminInitiateAuthRequest authRequest = AdminInitiateAuthRequest.builder()
                    .clientId("****")
                    .userPoolId("***")
                    .authParameters(authParameters)
                    .authFlow(AuthFlowType.ADMIN_NO_SRP_AUTH)
                    .build();



            CognitoIdentityProviderClient identityProviderClient = CognitoIdentityProviderClient.builder()
                    .region(Region.US_EAST_1)
                    .credentialsProvider(ProfileCredentialsProvider.create())
                    .build();

            AdminInitiateAuthResponse resp = identityProviderClient.adminInitiateAuth(authRequest);
            AuthenticationResultType resultType = resp.authenticationResult();
            System.out.println("IDTOKJEN-->"+resultType.idToken());
            idparams.put("cognito-idp.us-east-1.amazonaws.com/us-east-1_****", resultType.idToken());


            CognitoIdentityClient cognitoClient = CognitoIdentityClient.builder()
                    .region(Region.US_EAST_1)
                    .credentialsProvider(ProfileCredentialsProvider.create())
                    .build();


           // aws cognito-identity get-id --identity-pool-id "us-east-1:79968f3e-680d-4829-9f5b-af7044124885" --logins "cognito-identity:us-east-1:102805308787:identitypool/us-east-1:79968f3e-680d-4829-9f5b-af7044124885" --region us-east-1
//            String cognitoIdentityId = "79968f3e-680d-4829-9f5b-af7044124885";
            GetIdRequest request = (GetIdRequest)GetIdRequest.builder().
                    identityPoolId("us-east-1:79968f3e-680d-4829-9f5b-*****").logins(idparams).build();
            GetIdResponse responsex = cognitoClient.getId(request);
            System.out.println("Identity ID " + responsex.identityId());





            GetCredentialsForIdentityRequest getCredentialsForIdentityRequest = GetCredentialsForIdentityRequest.builder()
                    .identityId(responsex.identityId()).logins(idparams)
                    .build();



           // cognitoClient.getId()

            GetCredentialsForIdentityResponse response = cognitoClient.getCredentialsForIdentity(getCredentialsForIdentityRequest);
            System.out.println("Identity ID " + response.identityId() + ", Access key ID " + response.credentials().accessKeyId() +
                    "Secret Key-->" + response.credentials().secretKey() + "Session Token-->" + response.credentials().sessionToken());

            AwsSessionCredentials provider  =AwsSessionCredentials.create(response.credentials().accessKeyId(),
                    response.credentials().secretKey(), response.credentials().sessionToken());
ProfileCredentialsProvider providerProfile = ProfileCredentialsProvider.builder().build();

            StaticCredentialsProvider  credentialsProvider = StaticCredentialsProvider.create(provider);



            S3Client s3 = S3Client.builder()
                    .region(Region.US_EAST_1)
                    .credentialsProvider(credentialsProvider)
                    .build();
            GetObjectRequest objectRequest = GetObjectRequest
                    .builder()
                    .key("jpm/testfile-jpm.txt")
                    .bucket("anycompany-bucket-1689844403985")
                    .build();

            ListObjectsRequest objectRequestlist = ListObjectsRequest
                    .builder()
                    //.key("jpm/testfile-jpm.txt")
                    .bucket("anycompany-bucket-1689844403985").prefix("jpm")
                    .build();

            ///ResponseBytes<GetObjectResponse> objectBytes = s3.getObjectAsBytes(objectRequest);
            s3.listObjects(objectRequestlist);
          //  byte[] data = objectBytes.asByteArray();

            // Write the data to a local file.
//            File myFile = new File(path );
//            OutputStream os = new FileOutputStream(myFile);
//            os.write(data);
            System.out.println("Successfully obtained bytes from an S3 object");
           // os.close();
//
//            AdminInitiateAuthResponse response = identityProviderClient.adminInitiateAuth(authRequest);
//            AdminInitiateAuthResult authResult = client.adminInitiateAuth(authRequest);
//            AuthenticationResultType resultType = authResult.getAuthenticationResult();
//            System.out.println("Result Challenge is : " + response.challengeName() );
//            return response;
StartQueryExample.runAthena(credentialsProvider);
        } catch(Exception e) {
            e.printStackTrace();
            System.exit(1);
        }

    }

    public static void
    getObjectBytes (S3Client s3, String bucketName, String keyName, String path) {

        try {
            GetObjectRequest objectRequest = GetObjectRequest
                    .builder()
                    .key(keyName)
                    .bucket(bucketName)
                    .build();

            ResponseBytes<GetObjectResponse> x  = s3.getObjectAsBytes(objectRequest);
            System.out.println("Csame here");



        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
