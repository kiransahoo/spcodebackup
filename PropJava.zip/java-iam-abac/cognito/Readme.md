#  Amazon Cognito code examples for the SDK for Java

## Overview
Java example for running cognito iam abac
