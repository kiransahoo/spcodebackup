package com.example.realtimerte.service;

import com.example.realtimerte.model.SalesData;
import com.example.realtimerte.model.VideoLink;
import org.springframework.stereotype.Service;
import java.util.*;
import java.time.LocalDateTime;

@Service
public class DataService {
    private final Random random = new Random();
    private final String[] products = {"Laptop", "Phone", "Tablet", "Watch", "Headphones"};
    private List<SalesData> currentSalesData;
    
    public DataService() {
        currentSalesData = new ArrayList<>();
        updateSalesData();
    }
    
    public List<SalesData> getSalesData() {
        updateSalesData();
        return currentSalesData;
    }
    
    private void updateSalesData() {
        currentSalesData = new ArrayList<>();
        
        for (String product : products) {
            SalesData data = new SalesData();
            data.setProduct(product);
            data.setRevenue(random.nextDouble() * 1000);
            data.setQuantity(random.nextInt(50));
            data.setTimestamp(LocalDateTime.now());
            currentSalesData.add(data);
        }
    }
    
    public List<VideoLink> getVideoLinks() {
        List<VideoLink> links = new ArrayList<>();
        
        VideoLink link1 = new VideoLink();
        link1.setTitle("Product Overview");
        link1.setUrl("https://www.youtube.com/embed/abc123");
        link1.setDescription("Detailed product features and benefits");
        
        VideoLink link2 = new VideoLink();
        link2.setTitle("Tutorial");
        link2.setUrl("https://www.youtube.com/embed/def456");
        link2.setDescription("Step-by-step usage guide");
        
        VideoLink link3 = new VideoLink();
        link3.setTitle("Customer Testimonials");
        link3.setUrl("https://www.youtube.com/embed/ghi789");
        link3.setDescription("Real customer reviews and experiences");
        
        links.addAll(Arrays.asList(link1, link2, link3));
        return links;
    }
}