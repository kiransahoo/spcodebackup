// src/main/java/com/example/realtimerte/controller/DataController.java
package com.example.realtimerte.controller;

import com.example.realtimerte.model.SalesData;
import com.example.realtimerte.model.VideoLink;
import com.example.realtimerte.service.DataService;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class DataController {
    
    private final DataService dataService;
    
    public DataController(DataService dataService) {
        this.dataService = dataService;
    }
    
    @GetMapping("/data")
    public List<SalesData> getSalesData() {
        return dataService.getSalesData();
    }
    
    @GetMapping("/videos")
    public List<VideoLink> getVideoLinks() {
        return dataService.getVideoLinks();
    }
}