import React, { useState, useEffect } from 'react';
import { Editor } from '@tinymce/tinymce-react';
import axios from 'axios';

export default function App() {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 5000);
    return () => clearInterval(interval);
  }, []);

  const fetchData = async () => {
    setLoading(true);
    try {
      const response = await axios.get('http://localhost:8080/api/data');
      console.log('API Response:', response.data); // Debug log
      setData(response.data); // Direct access to data from axios response
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const createTable = () => {
    console.log('Creating table with data:', data); // Debug log
    if (!data || !data.length) {
      console.log('No data available');
      return '';
    }

    const headers = Object.keys(data[0]);
    let tableHtml = '<table style="border-collapse: collapse; width: 100%; margin: 1em 0;">';
    
    // Add headers
    tableHtml += '<thead><tr>';
    headers.forEach(header => {
      tableHtml += `<th style="border: 1px solid #ddd; padding: 8px; background-color: #f3f4f6;">${header}</th>`;
    });
    tableHtml += '</tr></thead>';

    // Add data rows
    tableHtml += '<tbody>';
    data.forEach(row => {
      tableHtml += '<tr>';
      headers.forEach(header => {
        const value = typeof row[header] === 'number' ? row[header].toFixed(2) : row[header];
        tableHtml += `<td style="border: 1px solid #ddd; padding: 8px;">${value}</td>`;
      });
      tableHtml += '</tr>';
    });
    tableHtml += '</tbody></table>';

    console.log('Generated table HTML'); // Debug log
    return tableHtml;
  };

  // Rest of your code remains exactly the same...
  return (
    <Editor
      apiKey='rt7vk1x1imqllhiqrnquv7l3bgliwnes7ojulc5i7liux83u'
      init={{
        height: 500,
        menubar: true,
        plugins: [
          // Core editing features
          'anchor', 'autolink', 'charmap', 'codesample', 'emoticons', 'image', 'link', 'lists', 'media', 'searchreplace', 'table', 'visualblocks', 'wordcount',
          // Premium features
          'checklist', 'mediaembed', 'casechange', 'export', 'formatpainter', 'pageembed', 'a11ychecker', 'tinymcespellchecker', 'permanentpen', 'powerpaste', 'advtable', 'advcode', 'editimage', 'advtemplate', 'ai', 'mentions', 'tinycomments', 'tableofcontents', 'footnotes', 'mergetags', 'autocorrect', 'typography', 'inlinecss', 'markdown',
          // Document converters
          'importword', 'exportword', 'exportpdf'
        ],
        toolbar: [
          {
            name: 'history', 
            items: ['undo', 'redo']
          },
          {
            name: 'styles',
            items: ['blocks', 'fontfamily', 'fontsize']
          },
          {
            name: 'formatting',
            items: ['bold', 'italic', 'underline', 'strikethrough']
          },
          {
            name: 'alignment',
            items: ['align', 'lineheight']
          },
          {
            name: 'indentation',
            items: ['bullist', 'numlist', 'checklist', 'indent', 'outdent']
          },
          {
            name: 'inserttools',
            items: ['link', 'image', 'media', 'table', 'mergetags', 'insertApiData']
          },
          {
            name: 'cleanup',
            items: ['removeformat']
          }
        ],
        tinycomments_mode: 'embedded',
        tinycomments_author: 'Author name',
        mergetags_list: [
          { value: 'First.Name', title: 'First Name' },
          { value: 'Email', title: 'Email' },
        ],
        ai_request: (request, respondWith) => respondWith.string(() => Promise.reject('See docs to implement AI Assistant')),
        exportpdf_converter_options: { 
          'format': 'Letter', 
          'margin_top': '1in', 
          'margin_right': '1in', 
          'margin_bottom': '1in', 
          'margin_left': '1in' 
        },
        exportword_converter_options: { 
          'document': { 
            'size': 'Letter' 
          } 
        },
        importword_converter_options: { 
          'formatting': { 
            'styles': 'inline', 
            'resets': 'inline', 
            'defaults': 'inline', 
          } 
        },
        setup: (editor) => {
          editor.ui.registry.addButton('insertApiData', {
            text: 'Insert API Data',
            icon: 'database',
            onAction: () => {
              if (loading) {
                editor.notificationManager.open({
                  text: 'Loading data...',
                  type: 'info',
                  timeout: 2000
                });
                return;
              }
              
              const tableHtml = createTable();
              if (tableHtml) {
                editor.insertContent(tableHtml);
                editor.notificationManager.open({
                  text: 'Data inserted successfully',
                  type: 'success',
                  timeout: 2000
                });
              } else {
                editor.notificationManager.open({
                  text: 'No data available',
                  type: 'warning',
                  timeout: 2000
                });
              }
            }
          });
        }
      }}
      initialValue=""
    />
  );
}