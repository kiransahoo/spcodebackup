package com.example;

import org.apache.spark.sql.*;
import org.apache.spark.sql.streaming.StreamingQuery;
import org.apache.spark.sql.streaming.StreamingQueryException;
import org.apache.spark.sql.streaming.Trigger;
import org.apache.spark.sql.types.*;
import static org.apache.spark.sql.functions.*;
import java.io.File;
import java.util.concurrent.TimeoutException;

public class CDCIcebergProcessor {
    private static final String MERGE_SQL = "MERGE INTO local.db.test_cdc_table t "
            + "USING (SELECT id, name, description, updated_at, __deleted FROM cdc_events) s "
            + "ON t.id = s.id "
            + "WHEN MATCHED AND s.__deleted = 'true' THEN DELETE "
            + "WHEN MATCHED THEN UPDATE SET "
            + "    t.name = s.name, "
            + "    t.description = s.description, "
            + "    t.updated_at = s.updated_at "
            + "WHEN NOT MATCHED AND s.__deleted != 'true' THEN "
            + "    INSERT (id, name, description, updated_at) "
            + "    VALUES (s.id, s.name, s.description, s.updated_at)";

    public static void main(String[] args) {
        // Create absolute paths for warehouse and checkpoints
        File currentDir = new File(System.getProperty("user.dir"));
        File warehouseDir = new File(currentDir, "warehouse");
        File checkpointDir = new File(currentDir, "checkpoints");

        // Create directories
        if (!warehouseDir.exists() && !warehouseDir.mkdirs()) {
            throw new RuntimeException("Failed to create warehouse directory: " + warehouseDir.getAbsolutePath());
        }
        if (!checkpointDir.exists() && !checkpointDir.mkdirs()) {
            throw new RuntimeException("Failed to create checkpoint directory: " + checkpointDir.getAbsolutePath());
        }

        // Get absolute paths
        final String warehousePath = warehouseDir.getAbsolutePath();
        final String checkpointPath = checkpointDir.getAbsolutePath();

        System.out.println("Warehouse path: " + warehousePath);
        System.out.println("Checkpoint path: " + checkpointPath);

        final SparkSession spark = createSparkSession(warehousePath);
        StreamingQuery query = null;

        try {
            spark.sparkContext().setLogLevel("ERROR");

            // Define schema for the CDC events
            StructType schema = new StructType()
                .add("id", DataTypes.LongType)
                .add("name", DataTypes.StringType)
                .add("description", DataTypes.StringType)
                .add("updated_at", DataTypes.LongType)
                .add("__deleted", DataTypes.StringType)
                .add("__op", DataTypes.StringType)
                .add("__table", DataTypes.StringType)
                .add("__db", DataTypes.StringType)
                .add("__ts_ms", DataTypes.LongType);

            // Create namespace and table
            spark.sql("CREATE NAMESPACE IF NOT EXISTS local.db");
            createIcebergTableIfNotExists(spark);

            // Read from Kafka with simplified configuration
            Dataset<Row> cdcEvents = spark
                .readStream()
                .format("kafka")
                .option("kafka.bootstrap.servers", "localhost:9092")
                .option("subscribe", "postgres.public.test_cdc")
                .option("startingOffsets", "earliest")
                .option("failOnDataLoss", "false")
                .option("maxOffsetsPerTrigger", "100")
                .load()
                .select(from_json(col("value").cast("string"), schema).as("data"))
                .select("data.*");

            // Process stream with micro-batch optimization
            query = processCDCEvents(cdcEvents, spark, checkpointPath);

            // Add shutdown hook
            final StreamingQuery finalQuery = query;
            Runtime.getRuntime().addShutdownHook(new Thread(() -> {
                try {
                    if (finalQuery != null && finalQuery.isActive()) {
                        finalQuery.stop();
                    }
                } catch (Exception e) {
                    System.err.println("Error during shutdown: " + e.getMessage());
                }
            }));

            // Monitor the streaming query
            monitorStreamingQuery(query);
            System.out.println("\n=== Final Table State ===");
            verifyIcebergTable(spark);
            exploreDataFiles(warehousePath);
            showTableData(spark);

        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
        } finally {
            cleanupResources(query, spark);
        }
    }
private static void monitorStreamingQuery(StreamingQuery query) {
        while (query != null && query.isActive()) {
            try {
                Thread.sleep(1000);  // Sleep for 1 second between checks
                System.out.println("Query is active: " + query.status().message());
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                System.err.println("Monitoring interrupted: " + e.getMessage());
                break;
            }
        }
    }

    private static SparkSession createSparkSession(String warehousePath) {
        return SparkSession
                .builder()
                .appName("CDC-Iceberg-Processor")
                .master("local[*]")
                .config("spark.sql.extensions", "org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions")
                .config("spark.sql.catalog.local", "org.apache.iceberg.spark.SparkCatalog")
                .config("spark.sql.catalog.local.type", "hadoop")
                .config("spark.sql.catalog.local.warehouse", warehousePath)
                .config("spark.sql.defaultCatalog", "local")
                .config("spark.sql.warehouse.dir", warehousePath)
                .config("spark.jars.packages", "org.apache.spark:spark-sql-kafka-0-10_2.12:3.5.0")
                .config("spark.driver.memory", "4g")
                .config("spark.executor.memory", "4g")
                .config("spark.memory.offHeap.enabled", "true")
                .config("spark.memory.offHeap.size", "2g")
                .config("spark.driver.maxResultSize", "2g")
                .config("spark.default.parallelism", "4")
                .config("spark.sql.shuffle.partitions", "4")
                .config("spark.driver.extraJavaOptions", "-Xss8m")
                .config("spark.executor.extraJavaOptions", "-Xss8m")
                .config("spark.sql.adaptive.enabled", "false")
                // Updated Kryo configuration
                .config("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
                .config("spark.kryo.registrationRequired", "false")
                .config("spark.kryoserializer.buffer", "256k")
                .config("spark.kryoserializer.buffer.max", "512m")
                // Network configurations
                .config("spark.hadoop.fs.defaultFS", "file:///")
                .config("spark.driver.host", "localhost")
                .config("spark.driver.bindAddress", "127.0.0.1")
                .getOrCreate();

    }


    private static void cleanupResources(StreamingQuery query, SparkSession spark) {
        try {
            if (query != null && query.isActive()) {
                query.stop();
                // Wait for the query to stop
                long timeout = System.currentTimeMillis() + 10000; // 10 seconds timeout
                while (query.isActive() && System.currentTimeMillis() < timeout) {
                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        break;
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("Error stopping query: " + e.getMessage());
        } finally {
            if (spark != null) {
                spark.close();
            }
        }
    }

    private static StreamingQuery processCDCEvents(Dataset<Row> cdcEvents, SparkSession spark, String checkpointPath) throws StreamingQueryException {
        try {
            return cdcEvents
                    .writeStream()
                    .foreachBatch((Dataset<Row> batch, Long batchId) -> {
                        if (!batch.isEmpty()) {
                            try {
                                // Handle deletes
                                Dataset<Row> deleteBatch = batch.filter(col("__deleted").equalTo("true"));
                                if (!deleteBatch.isEmpty()) {
                                    // Get IDs to delete
                                    String deleteIds = deleteBatch.select("id")
                                            .collectAsList()
                                            .stream()
                                            .map(row -> row.getLong(0))
                                            .map(String::valueOf)
                                            .collect(java.util.stream.Collectors.joining(","));

                                    if (!deleteIds.isEmpty()) {
                                        spark.sql("DELETE FROM local.db.test_cdc_table WHERE id IN (" + deleteIds + ")");
                                    }
                                }

                                // Handle updates and inserts
                                Dataset<Row> upsertBatch = batch.filter(col("__deleted").notEqual("true")
                                        .or(col("__deleted").isNull()));

                                if (!upsertBatch.isEmpty()) {
                                    // Register the batch as a temporary table in Spark SQL
                                    spark.createDataFrame(
                                            upsertBatch.select("id", "name", "description", "updated_at").collectAsList(),
                                            upsertBatch.schema()
                                    ).createOrReplaceTempView("updates");

                                    // Execute MERGE
                                    String mergeSql =
                                            "MERGE INTO local.db.test_cdc_table t " +
                                                    "USING (SELECT id, name, description, updated_at FROM updates) s " +
                                                    "ON t.id = s.id " +
                                                    "WHEN MATCHED THEN UPDATE SET " +
                                                    "    t.name = s.name, " +
                                                    "    t.description = s.description, " +
                                                    "    t.updated_at = s.updated_at " +
                                                    "WHEN NOT MATCHED THEN INSERT * ";

                                    spark.sql(mergeSql);
                                    spark.catalog().dropTempView("updates");
                                }

                                // Log progress
                                System.out.println("Processed batch " + batchId + " with " + batch.count() + " records");
                                System.out.println("\n=== Verifying Changes ===");
                                verifyIcebergTable(spark);
                                exploreDataFiles(spark.conf().get("spark.sql.catalog.local.warehouse"));
                                showTableData(spark);

                            } catch (Exception e) {
                                System.err.println("Error processing batch " + batchId + ": " + e.getMessage());
                                e.printStackTrace();
                            }
                        }
                    })
                    .option("checkpointLocation", checkpointPath + "/query")
                    .trigger(Trigger.ProcessingTime("10 seconds"))
                    .start();
        } catch (TimeoutException e) {
            throw new RuntimeException(e);
        }
    }
    private static void createIcebergTableIfNotExists(SparkSession spark) {
        spark.sql("CREATE TABLE IF NOT EXISTS local.db.test_cdc_table ("
                + "id BIGINT, "
                + "name STRING, "
                + "description STRING, "
                + "updated_at BIGINT) "
                + "USING iceberg "
                + "TBLPROPERTIES ("
                + "'write.merge.mode'='merge-on-read', "
                + "'write.update.mode'='merge-on-read', "
                + "'write.delete.mode'='merge-on-read', "
                + "'format-version'='2', "
                + "'write.distribution-mode'='none', "
                + "'write.update.isolation-level'='snapshot'"
                + ")");
    }
    private static void showTableData(SparkSession spark) {
        try {
            System.out.println("\n============== ICEBERG TABLE DATA ANALYSIS ==============");

            // Current Data
            System.out.println("\n1. Current Table Data:");
            spark.sql("SELECT * FROM local.db.test_cdc_table ORDER BY id").show(false);

            // Table History
            System.out.println("\n2. Table Modification History:");
            spark.sql("SELECT * FROM local.db.test_cdc_table.history").show(false);

            // Get snapshots and show them
            System.out.println("\n3. Available Snapshots:");
            Dataset<Row> snapshots = spark.sql("SELECT * FROM local.db.test_cdc_table.snapshots ORDER BY committed_at");
            snapshots.show(false);

            // Time Travel Examples
            System.out.println("\n4. Time Travel Queries for Last Few Snapshots:");

            // Get snapshot IDs
            snapshots.select("snapshot_id", "committed_at")
                    .limit(3)
                    .collectAsList()
                    .forEach(row -> {
                        String snapshotId = row.get(0).toString();
                        String timestamp = row.get(1).toString();
                        System.out.println("\nData at Snapshot " + snapshotId + " (Time: " + timestamp + ")");
                        try {
                            spark.sql("SELECT * FROM local.db.test_cdc_table VERSION AS OF " + snapshotId + " ORDER BY id")
                                    .show(false);
                        } catch (Exception e) {
                            System.err.println("Error querying snapshot " + snapshotId + ": " + e.getMessage());
                        }
                    });

            // Show recent changes
            System.out.println("\n5. Recent Changes in Table:");
            spark.sql("SELECT * FROM local.db.test_cdc_table.changes").show(false);

        } catch (Exception e) {
            System.err.println("Error querying table data: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Add these new methods to your existing class:

    private static void verifyIcebergTable(SparkSession spark) {
        try {
            // Get current data
            Dataset<Row> currentData = spark.sql("SELECT * FROM local.db.test_cdc_table");
            System.out.println("\n=== Current Table Data ===");
            System.out.println("Total Records: " + currentData.count());
            System.out.println("Schema: ");
            currentData.printSchema();
            System.out.println("\nSample Data:");
            currentData.show(5, false);

            // Get Iceberg metadata
            System.out.println("\n=== Iceberg Table History ===");
            spark.sql("SELECT * FROM local.db.test_cdc_table.history").show(5, false);

            // Show snapshots
            System.out.println("\n=== Iceberg Table Snapshots ===");
            spark.sql("SELECT * FROM local.db.test_cdc_table.snapshots").show(5, false);

        } catch (Exception e) {
            System.err.println("Error verifying table: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static void exploreDataFiles(String warehousePath) {
        File warehouseDir = new File(warehousePath);
        System.out.println("\n=== Exploring Data Files ===");
        System.out.println("Warehouse root: " + warehousePath);
        listDirectory(warehouseDir, 0);
    }

    private static void listDirectory(File dir, int level) {
        String indent = "  ".repeat(level);
        File[] files = dir.listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.isDirectory()) {
                    System.out.println(indent + "📁 " + file.getName());
                    listDirectory(file, level + 1);
                } else {
                    System.out.println(indent + "📄 " + file.getName() + " (" + file.length() + " bytes)");
                }
            }
        }
    }
}