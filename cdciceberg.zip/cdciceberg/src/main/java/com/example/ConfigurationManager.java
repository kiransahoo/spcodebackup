package com.example;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.JsonNode;
import org.apache.spark.sql.types.*;
import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

public class ConfigurationManager {
    private final JsonNode config;
    private final StructType cdcSchema;
    private final StructType tableSchema;

    public ConfigurationManager(String configPath) throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        this.config = mapper.readTree(new File(configPath));
        this.cdcSchema = buildSchema(config.path("cdcSchema"));
        this.tableSchema = buildSchema(config.path("tableSchema"));
    }

    private StructType buildSchema(JsonNode schemaNode) {
        List<StructField> fields = new ArrayList<>();
        schemaNode.fields().forEachRemaining(entry -> {
            String fieldName = entry.getKey();
            JsonNode fieldConfig = entry.getValue();
            String fieldType = fieldConfig.isObject() ?
                    fieldConfig.get("type").asText() :
                    fieldConfig.asText();
            boolean nullable = fieldConfig.isObject() ?
                    fieldConfig.path("nullable").asBoolean(true) :
                    true;
            fields.add(DataTypes.createStructField(fieldName, getSparkDataType(fieldType), nullable));
        });
        return DataTypes.createStructType(fields);
    }

    private DataType getSparkDataType(String type) {
        switch (type.toLowerCase()) {
            case "string":
                return DataTypes.StringType;
            case "long":
                return DataTypes.LongType;
            case "int":
                return DataTypes.IntegerType;
            case "boolean":
                return DataTypes.BooleanType;
            case "double":
                return DataTypes.DoubleType;
            case "float":
                return DataTypes.FloatType;
            case "binary":
                return DataTypes.BinaryType;
            case "timestamp":
                return DataTypes.TimestampType;
            case "date":
                return DataTypes.DateType;
            case "decimal":
                return DataTypes.createDecimalType();
            default:
                return DataTypes.StringType;
        }
    }

    public String getApplicationName() {
        return config.path("spark").path("appName").asText("CDC-Iceberg-Processor");
    }

    public String getSparkMaster() {
        return config.path("spark").path("master").asText("local[*]");
    }

    public Map<String, String> getSparkConfigs() {
        Map<String, String> configs = new HashMap<>();
        if (config.has("spark") && config.get("spark").has("config")) {
            config.get("spark").get("config").fields().forEachRemaining(entry ->
                    configs.put(entry.getKey(), entry.getValue().asText()));
        }

        // Add default configurations if not specified
        Map<String, String> defaultConfigs = new HashMap<>();
        defaultConfigs.put("spark.driver.memory", "4g");
        defaultConfigs.put("spark.executor.memory", "4g");
        defaultConfigs.put("spark.memory.offHeap.enabled", "true");
        defaultConfigs.put("spark.memory.offHeap.size", "2g");
        defaultConfigs.put("spark.driver.maxResultSize", "2g");
        defaultConfigs.put("spark.default.parallelism", "4");
        defaultConfigs.put("spark.sql.shuffle.partitions", "4");
        defaultConfigs.put("spark.serializer", "org.apache.spark.serializer.KryoSerializer");

        // Only add defaults if not already specified in config
        defaultConfigs.forEach(configs::putIfAbsent);

        return configs;
    }

    public Map<String, String> getKafkaOptions() {
        Map<String, String> options = new HashMap<>();
        if (config.has("kafka")) {
            config.get("kafka").fields().forEachRemaining(entry ->
                    options.put(entry.getKey(), entry.getValue().asText()));
        }

        // Add default Kafka options if not specified
        Map<String, String> defaultOptions = new HashMap<>();
        defaultOptions.put("kafka.bootstrap.servers", "localhost:9092");
        defaultOptions.put("startingOffsets", "earliest");
        defaultOptions.put("failOnDataLoss", "false");
        defaultOptions.put("maxOffsetsPerTrigger", "100");

        defaultOptions.forEach(options::putIfAbsent);

        return options;
    }

    public String getNamespace() {
        return String.format("%s.%s",
                config.path("target").path("catalog").asText("local"),
                config.path("target").path("namespace").asText("db"));
    }

    public String getFullTableName() {
        return String.format("%s.%s",
                getNamespace(),
                config.path("target").path("table").asText("test_cdc_table"));
    }

    public String getDeleteFlagColumn() {
        return config.path("cdc").path("deleteFlagColumn").asText("__deleted");
    }

    public String getDeleteFlagValue() {
        return config.path("cdc").path("deleteFlagValue").asText("true");
    }

    public String getPrimaryKeyColumn() {
        return config.path("target").path("primaryKey").asText("id");
    }

    public String getTriggerInterval() {
        return config.path("processing").path("triggerInterval").asText("10 seconds");
    }

    public boolean isDebugMode() {
        return config.path("processing").path("debug").asBoolean(false);
    }

    public List<String> getTargetColumns() {
        // If columns are explicitly specified in config, use those
        if (config.has("target") && config.get("target").has("columns")) {
            return StreamSupport.stream(
                            config.get("target").get("columns").spliterator(), false)
                    .map(JsonNode::asText)
                    .collect(Collectors.toList());
        }

        // Otherwise, use all columns from table schema
        return Arrays.stream(tableSchema.fieldNames())
                .collect(Collectors.toList());
    }

    public StructType getCDCSchema() {
        return cdcSchema;
    }

    public StructType getTableSchema() {
        return tableSchema;
    }

    // Optional: Method to validate configuration
    public void validate() throws IllegalArgumentException {
        List<String> errors = new ArrayList<>();

        // Validate required fields
        if (!config.has("cdcSchema")) {
            errors.add("CDC schema configuration is missing");
        }
        if (!config.has("tableSchema")) {
            errors.add("Target table schema configuration is missing");
        }
        if (!config.has("kafka")) {
            errors.add("Kafka configuration is missing");
        }

        // Validate schema compatibility
        Set<String> cdcColumns = new HashSet<>(Arrays.asList(cdcSchema.fieldNames()));
        Set<String> targetColumns = new HashSet<>(getTargetColumns());
        if (!cdcColumns.containsAll(targetColumns)) {
            errors.add("CDC schema must contain all target table columns");
        }

        if (!errors.isEmpty()) {
            throw new IllegalArgumentException(
                    "Configuration validation failed:\n" + String.join("\n", errors));
        }
    }
}