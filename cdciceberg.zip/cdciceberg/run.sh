#!/bin/bash

export JAVA_OPTS="
-Xmx4g \
-Xms4g \
-Xss8m \
-XX:MaxMetaspaceSize=512m \
-XX:+UseG1GC \
-XX:MaxGCPauseMillis=20 \
-XX:InitiatingHeapOccupancyPercent=35 \
-XX:+ExplicitGCInvokesConcurrent \
-Dlog4j.configuration=file:log4j.properties \
"

export SPARK_OPTS="
--add-exports java.base/sun.nio.ch=ALL-UNNAMED \
--add-exports java.base/sun.security.action=ALL-UNNAMED \
--add-opens java.base/java.lang=ALL-UNNAMED \
--add-opens java.base/java.lang.invoke=ALL-UNNAMED \
--add-opens java.base/java.nio=ALL-UNNAMED \
--add-opens java.base/sun.nio.ch=ALL-UNNAMED \
--add-opens java.base/java.util=ALL-UNNAMED \
--add-opens java.base/java.util.concurrent=ALL-UNNAMED \
--add-opens java.base/java.util.concurrent.atomic=ALL-UNNAMED \
--add-opens java.base/java.io=ALL-UNNAMED \
--add-opens java.base/java.net=ALL-UNNAMED \
--add-opens java.base/java.util.concurrent.locks=ALL-UNNAMED \
--add-opens java.base/java.util.regex=ALL-UNNAMED \
--add-opens java.base/java.util.zip=ALL-UNNAMED \
--add-opens java.base/sun.net.dns=ALL-UNNAMED \
"

# Clean and build
mvn clean package

# Run the application
java $JAVA_OPTS $SPARK_OPTS -jar target/cdc-iceberg-processor-1.0-SNAPSHOT.jar