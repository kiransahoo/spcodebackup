## Deploy RUST AND WASI target
curl https://sh.rustup.rs -sSf | sh
rustup target add wasm32-wasi  

##  this the command to run the server locally 
cargo watch -c -s 'cargo clippy&&cargo run --release -- --config sec_config.yaml --schema schema.graphql'


##  this command is to perform ddos against the proxy locally.
// we can run this command multiple time
//cargo watch -c -s 'cargo clippy&&cargo run --release --target=ddos'
//to build ddos- cargo build --release --bin ddos
//to do ddos, this is working and not the earlier one
cargo watch -c -s 'cargo clippy && cargo run --release --bin ddos'


## Use Dockerfile for Rust native image
docker build -t shieldproxy:latest .

## UseDockerfileWASM for WASM target
## Building WASM target is different, Please follow the below steps
cargo build --target=wasm32-wasi --release
docker build -t shieldproxywasm:latest .

## Deployment file is provided for instructions to deploy it in EKS
// check sec_config.yaml
// to add services and rate limits
// path should be unique for each service

## docker push command
docker tag shieldproxy kiransahoo****/shieldproxy:latest
docker push kiransahoo****/shieldproxy:latest

