#!/bin/sh -x
eval "$(minikube --shell sh docker-env)"
docker build -t shieldproxy . --network=host