#!/bin/sh
a="/$0"
a="${a%/*}"
a="${a:-.}"
a="${a##/}/"
BINDIR=$(
  cd "$a"
  pwd
)
CONTAINER_NAME=rustbuilder
docker start $CONTAINER_NAME || ./create_rustbuilder.sh
TARGET_DIR="target/$CONTAINER_NAME"
DOCKER_WORKDIR="/host$BINDIR"
docker exec -itu $USER $CONTAINER_NAME /bin/sh -c "
  cd $DOCKER_WORKDIR || exit 1;
  mkdir -p $TARGET_DIR || exit 2
  cargo build --release --target-dir=$TARGET_DIR || exit 3;
" || exit
# eval "$(minikube --shell sh docker-env)"
docker build -f Dockerfile.fast -t shieldproxy . --network=host
