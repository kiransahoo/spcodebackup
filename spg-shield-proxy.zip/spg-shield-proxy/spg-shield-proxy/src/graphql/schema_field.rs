/**
GQL Cost Directive
Author: Kiran Sahoo
Date: April 30, 2023
*/
#[derive(Debug)]
pub struct SchemaField {
  // variables required to calculate cost
  pub complexity: i64,
  pub servercost: i64,
  pub dbcost: i64,
  pub use_multipliers: bool,
  pub multipliers: Vec<String>,
  pub provides: Vec<String>,
  // these are not used to calculate cost
  pub args: Vec<String>,
  pub type_: String,
}

impl Default for SchemaField {
  fn default() -> Self {
    Self {
      complexity: 1,
      servercost: 0,
      dbcost: 0,
      use_multipliers: true,
      multipliers: Vec::new(),
      provides: Vec::new(),
      args: Vec::new(),
      type_: "".to_owned(), // this is not used in calculation.
    }
  }
}
