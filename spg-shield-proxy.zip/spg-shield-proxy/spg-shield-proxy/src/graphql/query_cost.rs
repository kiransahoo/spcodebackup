/**
This file contains Rust code for GQL Static Cost Analysis
Author: Kiran Sahoo
Date: May 16, 2023
*/
use crate::config::ServiceConf;

use anyhow::{bail, Result};
use graphql_parser::query::{Definition, Document};
use graphql_parser::{
  query::{Number, OperationDefinition, Selection},
  schema::Value,
};

use super::schema_field::SchemaField;
use super::Schema;
const INDENT_BLANK_SPACE: &str = "                                            ";

pub struct Query<'a> {
  pub query: Document<'a, &'a str>,
  schema: &'a Schema<'a>,
  service: &'a ServiceConf,
}

impl<'g> Query<'g> {
  #[inline]
  pub fn new(query: &'g str, schema: &'g Schema<'g>, service: &'g ServiceConf) -> Result<Self> {
    let query = graphql_parser::parse_query(query)?;
    Ok(Self {
      query,
      schema,
      service,
    })
  }
  #[inline]
  pub fn calculate_cost(&'g self) -> Result<i64> {
    trace!(" Calculating cost for the query.");
    let mut cost = 0;
    let mut recursion_count = 0;
    let mut multiplier_product = 1;
    let mut recursion_stack = Vec::<(&'g str, &'g str)>::new();
    for def in &self.query.definitions {
      let items = match get_selection(def) {
        Some(item) => item,
        None => continue,
      };
      self.do_calculate(
        items,
        "Query",
        &mut cost,
        &mut recursion_stack,
        &mut recursion_count,
        &mut multiplier_product,
      )?;
    }
    Ok(cost)
  }

  #[inline]
  fn do_calculate<'a>(
    &self,
    selections: &'g Vec<Selection<'a, &'a str>>,
    parent_struct: &'g str,
    cost: &mut i64,
    recursion_stack: &mut Vec<(&'g str, &'g str)>,
    recursion_count: &mut u32,
    multiplier_product: &mut i64,
  ) -> Result<()> {
    let depth = recursion_stack.len();
    let default_limit: &[(&str, Value<&str>)] = &[("__limit__", Value::Int(Number::from(1)))];
    for item in selections {
      match item {
        Selection::Field(field) => {
          let mut has_recursed = recursion_stack.contains(&(parent_struct, field.name));
          recursion_stack.push((parent_struct, field.name));
          let field_cost = match self.schema.get_field(parent_struct, field.name) {
            Some(o) => o,
            None => bail!("query invalid as per schema {parent_struct}.{}", field.name),
          };
          let indent = &INDENT_BLANK_SPACE[0..depth * 2];
          // trace!("{indent}Field {}({:?}) {{ {field:?}", field.name, field.arguments);
          if has_recursed && field.selection_set.items.is_empty() {
            has_recursed = false; // ignore scalar fields
          }
          let has_recursed = has_recursed;
          if has_recursed {
            *recursion_count += 1;
          }
          let &SchemaField {
            complexity,
            dbcost,
            servercost,
            ..
          } = &field_cost;
          let &ServiceConf {
            multiplier_dbcost,
            multiplier_servercost,
            multiplier_recursion,
            ..
          } = &self.service;
          let mut multiplier_arg_cost = 0;
          let arguments = match field.arguments.is_empty() {
            false => &*field.arguments,
            true => default_limit,
          };
          let mut multiplier_debug = "(".to_owned();
          for (name, value) in arguments {
            if *name != "limit" && *name != "__limit__" {
              trace!("name of arg {name}");
              if !field_cost.args.iter().any(|a| a == name) {
                bail!("argument {name} is not present in the schema args");
              }
              if !field_cost.multipliers.iter().any(|m| m == name) {
                continue;
              }
            }
            let multiplier_cost = match value {
              Value::Int(n) => n.as_i64().unwrap_or(0),
              Value::List(v) => v.len().try_into().unwrap_or(0),
              _other => bail!("limit is not a number {_other}"),
            };
            multiplier_arg_cost += multiplier_cost;
            if log_enabled!(log::Level::Trace) {
              multiplier_debug += &format!("{name}:{multiplier_cost}+")
            }
          }
          let mut recursion_debug = "".to_owned();
          let mut recursion_cost = 0;
          if has_recursed {
            recursion_cost = *cost * multiplier_recursion.pow(*recursion_count);
            if log_enabled!(log::Level::Trace) {
              recursion_debug +=
              &format!("prev:{cost} * {multiplier_recursion} (recursion x{recursion_count})={recursion_cost} +");
            }
          }
          if multiplier_arg_cost == 0 {
            multiplier_arg_cost = 1;
          }
          let this_field_multiplier_product = multiplier_arg_cost;
          let mut prev_multiplier_product_debug = "".to_owned();
          if log_enabled!(log::Level::Trace) && this_field_multiplier_product > 1 {
            prev_multiplier_product_debug = format!("* prev:{multiplier_product}");
          }
          if log_enabled!(log::Level::Trace) {
            multiplier_debug.pop();
            multiplier_debug += &format!(
          " = {this_field_multiplier_product}) * complexity:{complexity} {prev_multiplier_product_debug}"
        );
          }
          let is_scaler = field.selection_set.items.is_empty();
          let multiply_previous_if_scaler = match is_scaler {
            true => 1,
            false => *multiplier_product,
          };
          let this_field_cost = recursion_cost
            + this_field_multiplier_product * complexity * multiply_previous_if_scaler
            + servercost * multiplier_servercost
            + dbcost * multiplier_dbcost;

          *multiplier_product *= this_field_multiplier_product;

          if has_recursed {
            *cost = this_field_cost;
          } else {
            *cost += this_field_cost;
          }
          // TODO: We can also return early by comparing cost with the max allowed cost in the config.
          if log_enabled!(log::Level::Trace) {
            let field_name = &field.name;
            // debugging
            let debug_args = &field
              .arguments
              .iter()
              .map(|f| format!("{}:{}", f.0, f.1))
              .collect::<Vec<_>>()
              .join(", ");
            let (bo, bc) = match field.arguments.is_empty() {
              true => (' ', ' '),
              false => ('(', ')'), //  bracket open and close
            };
            let cb = match is_scaler {
              true => ' ',
              false => '{',
            };
            let prefix = format!("{indent}{field_name}{bo}{debug_args}{bc} {cb}");
            let servercost_debug = match *servercost == 0 {
              true => "".to_owned(),
              false => {
                format!("+ servercost:{servercost} * multiplier_servercost:{multiplier_servercost}")
              }
            };
            let dbcost_debug = match *dbcost == 0 {
              true => "".to_owned(),
              false => {
                format!("+ dbcost:{dbcost} * multiplier_dbcost:{multiplier_dbcost}")
              }
            };
            trace!(
            "{prefix: <45} # {recursion_debug} {multiplier_debug} {servercost_debug} {dbcost_debug}\
             = ({this_field_cost}) => {cost}"
          );
          }
          if is_scaler {
            continue;
          }
          self.do_calculate(
            &field.selection_set.items,
            &field_cost.type_,
            cost,
            recursion_stack,
            recursion_count,
            multiplier_product,
          )?;
          if has_recursed {
            *recursion_count -= 1;
          }
          if this_field_multiplier_product > 0 {
            *multiplier_product /= this_field_multiplier_product;
          }
          recursion_stack.pop();
          trace!("{indent}}}");
        }
        Selection::FragmentSpread(o) => trace!("FragmentSpread {o:?}"),
        Selection::InlineFragment(o) => trace!("InlineFragment {o:?}"),
      }
    }
    Ok(())
  }
}

#[inline]
fn get_selection<'a>(def: &'a Definition<'a, &'a str>) -> Option<&'a Vec<Selection<'a, &'a str>>> {
  match def {
    Definition::Operation(operation) => match operation {
      OperationDefinition::Query(query) => return Some(&query.selection_set.items),
      OperationDefinition::SelectionSet(selection_set) => return Some(&selection_set.items),
      OperationDefinition::Mutation(o) => trace!("Mutation {o:?}"),
      OperationDefinition::Subscription(o) => trace!("Subscription {o:?}"),
    },
    Definition::Fragment(d) => trace!("Fragment def {d:?}"),
  }
  None
}
