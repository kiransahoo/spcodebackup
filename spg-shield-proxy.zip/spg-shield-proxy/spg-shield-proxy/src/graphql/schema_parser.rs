/**
GQL Schema Parser
Author: Kiran Sahoo
Date: April 30, 2023
*/
use super::schema_field::SchemaField;
use anyhow::bail;
use graphql_parser::schema::{Definition, ObjectType, TypeDefinition};
use graphql_parser::schema::{Type, Value};
pub struct Schema<'a> {
  pub fieldmap: HashMap<&'a str, HashMap<&'a str, SchemaField>>,
}
use std::collections::HashMap;

impl SchemaField {
  fn parse_directive_argument<'a>(
    &mut self,
    arg: &(&str, Value<'a, &'a str>),
  ) -> anyhow::Result<()> {
    match arg {
      ("complexity", Value::Int(n)) => self.complexity = n.as_i64().unwrap_or(1),
      ("servercost", Value::Int(n)) => self.servercost = n.as_i64().unwrap_or(1), // was network
      ("dbcost", Value::Int(n)) => self.dbcost = n.as_i64().unwrap_or(1),
      ("useMultipliers", Value::Boolean(bool)) => self.use_multipliers = *bool,
      ("multipliers", Value::List(multipliers)) => {
        for m in multipliers {
          if let Value::String(m) = m {
            self.multipliers.push(m.to_owned())
          }
        }
      }
      ("provides", Value::List(provides)) => {
        for p in provides {
          if let Value::String(p) = p {
            self.provides.push(p.to_owned());
          }
        }
      }
      _other => bail!("invalid field arg name or arg type, '{arg:?}'"),
    }
    Ok(())
  }
}

impl<'g> Schema<'g> {
  pub fn new(schema: &'g str) -> anyhow::Result<Self> {
    let schema = graphql_parser::parse_schema::<&str>(schema)?;
    let definitions = &schema.definitions;
    let mut schema = Schema {
      fieldmap: HashMap::new(),
    };
    for def in definitions {
      match def {
        Definition::TypeDefinition(TypeDefinition::Object(o)) => schema.parse_object_fields(o)?,
        // Definition::TypeDefinition(d) => trace!("|- typedef {d:?}"),
        // Definition::DirectiveDefinition(d) => trace!("|- directive {d:?}"),
        // Definition::TypeExtension(d) => trace!("|- typeext {d:?}"),
        // Definition::SchemaDefinition(d) => trace!("|- Schema {d:?}"),
        _other => {}
      }
    }
    for (type_, conf) in &schema.fieldmap {
      trace!("Cached {type_: <20} @{conf:?}");
    }
    Ok(schema)
  }
  #[inline]
  pub fn get_field(&self, struct_name: &str, field_name: &str) -> Option<&SchemaField> {
    self.fieldmap.get(struct_name).map(|f| f.get(field_name))?
  }

  fn parse_object_fields<'a: 'g>(&mut self, o: &ObjectType<'a, &'a str>) -> anyhow::Result<()> {
    trace!("type {} {{", o.name);
    for f in &o.fields {
      let mut field = SchemaField::default();
      for arg in &f.arguments {
        field.args.push(arg.name.to_owned());
      }
      if let Some(override_directive) = f.directives.iter().find(|d| d.name == "cost") {
        for arg in &override_directive.arguments {
          field.parse_directive_argument(arg)?
        }
      };
      let type_map = match self.fieldmap.get_mut(o.name) {
        Some(o) => o,
        None => {
          self.fieldmap.insert(o.name, HashMap::new());
          self.fieldmap.get_mut(o.name).expect("should never happen")
        }
      };
      let field_type = resolve_field_type(&f.field_type);
      field.type_ = field_type.to_owned();
      let typeid = format!("{}.{}", o.name, f.name);
      trace!("  {typeid: <14} @{field:?}");
      type_map.insert(f.name, field);
    }
    trace!("}}");
    Ok(())
  }
}

fn resolve_field_type<'a>(field_type: &Type<'a, &'a str>) -> &'a str {
  match field_type {
    Type::NamedType(t) => t,
    Type::ListType(t) => resolve_field_type(t),
    Type::NonNullType(t) => resolve_field_type(t),
  }
}
