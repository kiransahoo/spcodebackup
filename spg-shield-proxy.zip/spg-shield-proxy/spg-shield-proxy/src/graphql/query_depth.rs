/**
This file contains Rust code for GQL Depth Analysis
Author: Kiran Sahoo
Date: April 30, 2023
*/
use graphql_parser::query::{
  Definition, Document, FragmentDefinition, Mutation, OperationDefinition, Query as GraphqlQuery,
  Selection, SelectionSet, Subscription,
};
use std::collections::HashMap;
use std::error::Error;
use std::fmt::{Display, Formatter, Result as FmtResult};
use std::slice::Iter;

use super::Query;

impl<'g> Query<'g> {
  #[inline]
  pub fn has_depth_limit_exceeded(&'g self, max_depth: usize) -> bool {
    if max_depth == 0 {
      return false; // zero means disabled
    }
    match QueryDepthAnalyzer::new(&self.query).verify(max_depth) {
      Ok(_depth) => false,
      Err(_err) => true,
    }
  }
}

#[derive(Debug, PartialEq)]
pub struct ExceedMaxDepth {
  limit: usize,
}
impl ExceedMaxDepth {
  #[inline]
  pub fn new(limit: usize) -> Self {
    Self { limit }
  }
}
impl Display for ExceedMaxDepth {
  fn fmt(&self, f: &mut Formatter<'_>) -> FmtResult {
    write!(f, "your query exceeded the depth limit: {}", self.limit)
  }
}
impl Error for ExceedMaxDepth {}
pub struct QueryDepthAnalyzer<'a> {
  fragments: HashMap<String, FragmentDefinition<'a, &'a str>>,
  document: &'a Document<'a, &'a str>,
}
#[inline]
fn fragments_from_definitions<'a>(
  definitions: Iter<'_, Definition<'a, &'a str>>,
) -> HashMap<String, FragmentDefinition<'a, &'a str>> {
  definitions.fold(HashMap::new(), |mut acc, val| {
    if let Definition::Fragment(def) = val {
      acc.insert(def.name.to_string(), def.clone());
    }
    acc
  })
}
impl<'g> QueryDepthAnalyzer<'g> {
  #[inline]
  pub fn new(document: &'g Document<'g, &'g str>) -> Self {
    let fragments = fragments_from_definitions(document.definitions.iter());
    Self {
      fragments,
      document,
    }
  }
  #[inline]
  fn determine_depth_of_selection_set<'a>(
    &self,
    selection_set: &SelectionSet<'a, &'a str>,
    depth: usize,
    limit: usize,
  ) -> Result<usize, ExceedMaxDepth> {
    let mut greater_depth: usize = depth;
    for item in selection_set.items.iter() {
      let depth = self.determine_depth_of_selection(item, depth, limit);
      match depth {
        Ok(val) => {
          if val > limit {
            return Err(ExceedMaxDepth::new(limit));
          }
          if val > greater_depth {
            greater_depth = val;
          }
        }
        Err(err) => return Err(err),
      }
    }
    Ok(greater_depth)
  }
  #[inline]
  fn determine_depth_of_selection<'a>(
    &self,
    selection: &Selection<'a, &'a str>,
    depth: usize,
    limit: usize,
  ) -> Result<usize, ExceedMaxDepth> {
    match selection {
      Selection::Field(f) => {
        self.determine_depth_of_selection_set(&f.selection_set, depth + 1, limit)
      }
      Selection::FragmentSpread(fs) => {
        if let Some(f_def) = self.fragments.get(fs.fragment_name) {
          self.determine_depth_of_selection_set(&f_def.selection_set, depth, limit)
        } else {
          Ok(0)
        }
      }
      Selection::InlineFragment(inf) => {
        self.determine_depth_of_selection_set(&inf.selection_set, depth, limit)
      }
    }
  }
  #[inline]
  fn determine_depth_of_query<'a>(
    &self,
    query: &GraphqlQuery<'a, &'a str>,
    depth: usize,
    limit: usize,
  ) -> Result<usize, ExceedMaxDepth> {
    self.determine_depth_of_selection_set(&query.selection_set, depth, limit)
  }
  #[inline]
  fn determine_depth_of_mutation<'a>(
    &self,
    mutation: &Mutation<'a, &'a str>,
    depth: usize,
    limit: usize,
  ) -> Result<usize, ExceedMaxDepth> {
    self.determine_depth_of_selection_set(&mutation.selection_set, depth, limit)
  }
  #[inline]
  fn determine_depth_of_subscription<'a>(
    &self,
    subscription: &Subscription<'a, &'a str>,
    depth: usize,
    limit: usize,
  ) -> Result<usize, ExceedMaxDepth> {
    self.determine_depth_of_selection_set(&subscription.selection_set, depth, limit)
  }
  #[inline]
  pub fn verify(&self, limit: usize) -> Result<usize, ExceedMaxDepth> {
    let mut depth = 0;
    for definition in self.document.definitions.iter() {
      let depth_result = if let Definition::Operation(def) = definition {
        match def {
          OperationDefinition::Query(q) => self.determine_depth_of_query(q, 0, limit),
          OperationDefinition::Mutation(m) => self.determine_depth_of_mutation(m, 0, limit),
          OperationDefinition::Subscription(s) => self.determine_depth_of_subscription(s, 0, limit),
          OperationDefinition::SelectionSet(ss) => {
            self.determine_depth_of_selection_set(ss, 0, limit)
          }
        }
      } else {
        Ok(0)
      };
      match depth_result {
        Ok(val) => {
          if val > depth {
            depth = val
          }
        }
        Err(err) => return Err(err),
      }
    }
    Ok(depth)
  }
}
