/**
Different Packages
Author: Kiran Sahoo
Date: May 1, 2023
*/
//cost calculator

pub use query_cost::Query;
pub use schema_parser::Schema;
// #[cfg(test)]
// pub mod test {
//   use super::schema_parser::Schema;
//   #[test]
//   fn default_cost_is_working() {
//     let schema_parser = "type Query { field: String }";
//     let cost = Schema::new(schema_parser)
//       .unwrap()
//       .calculate("query { field }")
//       .unwrap();
//     assert_eq!(cost, 10)
//   }
// }

mod query_cost;
mod query_depth;
mod schema_field;
mod schema_parser;
