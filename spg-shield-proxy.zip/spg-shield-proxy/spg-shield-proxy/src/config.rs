/**
Config Parser
Author: Kiran Sahoo
Date: May 1, 2023
*/
use std::time::Instant;

use dashmap::DashMap;
use governor::{
  clock::MonotonicClock, middleware::NoOpMiddleware, state::InMemoryState, RateLimiter,
};
use once_cell::sync::Lazy;

pub type RateLimit =
  RateLimiter<String, DashMap<String, InMemoryState>, MonotonicClock, NoOpMiddleware<Instant>>;

#[derive(Debug)]
pub struct ServiceConf {
  pub path: String,
  pub upstream_endpoint: String,
  pub failover_endpoint: Option<String>,
  pub max_allowed_cost: i64,
  pub multiplier_dbcost: i64,
  pub multiplier_recursion: i64,
  pub multiplier_servercost: i64,
  pub ratelimit: Option<RateLimit>,
  pub ratelimit_session: Option<RateLimit>,
  pub upstream_retry_count: usize,
}

#[derive(Debug)]
pub struct Config {
  pub port: u16,
  pub max_depth: usize,
  pub secret_key: String,
  pub enable_auth: bool,
  pub upstream_timeout_sec: u64,
  pub services: Vec<ServiceConf>,
  pub ratelimit: Option<RateLimit>,
}

mod inner {
  use crate::args::ARGS;

  use super::{Config, ServiceConf};
  use governor::{Quota, RateLimiter};
  use hyper::Uri;
  use std::{
    io::Read,
    num::{NonZeroU16, NonZeroU32},
  };
  #[derive(Debug, serde::Deserialize)]
  struct ServiceConfInner {
    path: String,
    max_allowed_cost: Option<i64>,
    multiplier_dbcost: Option<i64>,
    multiplier_recursion: Option<i64>,
    multiplier_servercost: Option<i64>,
    ratelimit_per_minute: Option<u32>,
    ratelimit_per_session_per_minute: Option<u32>,
    upstream_endpoint: String,
    failover_endpoint: Option<String>,
    upstream_retry_count: Option<usize>,
  }

  #[derive(Debug, serde::Deserialize)]
  struct ConfigInner {
    max_depth: usize,
    max_allowed_cost: i64,
    ratelimit_per_minute: u32,
    ratelimit_per_session_per_minute: u32,
    port: NonZeroU16,
    secret_key: Option<String>,
    enable_auth: bool,
    multiplier_dbcost: i64,
    multiplier_recursion: i64,
    multiplier_servercost: i64,
    upstream_retry_count: usize,
    services: Vec<ServiceConfInner>,
    upstream_timeout_sec: u64,
  }

  impl Config {
    pub fn read_config() -> Self {
      let config_file = &ARGS.config;
      let mut file = match std::fs::File::open(config_file) {
        Ok(file) => file,
        Err(err) => panic!("failed to open file {config_file} {err:?}"),
      };
      let mut str = String::new();
      match file.read_to_string(&mut str) {
        Ok(_n) => (),
        Err(err) => panic!("failed to read file {config_file} {err:?}"),
      };
      let inner: ConfigInner = match serde_yaml::from_str(&str) {
        Ok(inner) => inner,
        Err(err) => panic!("failed to read {config_file} {err:?}"),
      };
      let services = inner
        .services
        .into_iter()
        .map(|c| {
          let ratelimit_per_minute = c.ratelimit_per_minute.unwrap_or(inner.ratelimit_per_minute);
          let ratelimit_per_session_per_minute = c
            .ratelimit_per_session_per_minute
            .unwrap_or(inner.ratelimit_per_session_per_minute);
          assert!(
            ratelimit_per_session_per_minute <= ratelimit_per_minute,
            "ratelimit_per_session_per_minute cannot be greater than ratelimit_per_minute"
          );
          let ratelimit = NonZeroU32::new(ratelimit_per_minute)
            .map(|n| RateLimiter::dashmap(Quota::per_minute(n)));
          let ratelimit_session = NonZeroU32::new(ratelimit_per_session_per_minute)
            .map(|n| RateLimiter::dashmap(Quota::per_minute(n)));
          let _uri = &c
            .upstream_endpoint
            .parse::<Uri>()
            .unwrap_or_else(|err| panic!("invalid upstream_endpoint url {err:?}"));
          if let Some(url) = &c.failover_endpoint {
            url
              .parse::<Uri>()
              .unwrap_or_else(|err| panic!("invalid failover_endpoint url {err:?}"));
          }
          ServiceConf {
            ratelimit,
            ratelimit_session,
            max_allowed_cost: c.max_allowed_cost.unwrap_or(inner.max_allowed_cost),
            multiplier_dbcost: c.multiplier_dbcost.unwrap_or(inner.multiplier_dbcost),
            multiplier_recursion: c.multiplier_recursion.unwrap_or(inner.multiplier_recursion),
            multiplier_servercost: c
              .multiplier_servercost
              .unwrap_or(inner.multiplier_servercost),
            path: c.path,
            upstream_endpoint: c.upstream_endpoint,
            failover_endpoint: c.failover_endpoint,
            upstream_retry_count: c.upstream_retry_count.unwrap_or(inner.upstream_retry_count),
          }
        })
        .collect();
      let ratelimit = NonZeroU32::new(inner.ratelimit_per_minute)
        .map(|n| RateLimiter::dashmap(Quota::per_minute(n)));
      Config {
        port: inner.port.try_into().unwrap_or(3005),
        max_depth: inner.max_depth,
        secret_key: inner.secret_key.unwrap_or_else(|| "".into()),
        enable_auth: inner.enable_auth,
        upstream_timeout_sec: inner.upstream_timeout_sec,
        services,
        ratelimit,
      }
    }
    pub fn init(&self) {}
  }
}

pub static CONFIG: Lazy<Config> = Lazy::new(Config::read_config);
