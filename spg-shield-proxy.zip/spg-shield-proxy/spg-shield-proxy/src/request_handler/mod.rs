use std::borrow::Cow;
use std::io::Read;
use std::time::Duration;

use crate::args::ARGS;
use crate::config::CONFIG;
use crate::graphql::{Query, Schema};

use hyper::Request;
use hyper::{Body, Response, StatusCode, Uri};
use serde::Deserialize;

use self::client::CLIENT;
use self::ratelimit::IsWithinLimit;
use once_cell::sync::Lazy;
static DEFAULT_RATELIMIT_KEY: Lazy<String> = Lazy::new(|| "".to_owned());

static SCHEMA: Lazy<Schema> = Lazy::new(|| {
  let schema_path = &ARGS.schema;
  let mut file = match std::fs::File::open(schema_path) {
    Ok(file) => file,
    Err(err) => panic!("failed to open {schema_path}, {err}"),
  };
  let mut schema = "".to_owned();
  if let Err(err) = file.read_to_string(&mut schema) {
    panic!("Failed to read {schema_path}, {err:?}");
  }
  let schema: &'static str = Box::leak(schema.into_boxed_str());
  Schema::new(schema).unwrap_or_else(|err| panic!("failed to parse {schema_path}, {err:?}"))
});
pub fn init() {
  let _ = *SCHEMA; // force init SCHEMA at boot;
}

#[inline]
pub async fn handle(mut req: Request<Body>) -> hyper::http::Result<Response<Body>> {
  let instant = std::time::Instant::now();
  let mut proxy_elapsed = 0.0;
  let res = do_handle(&mut req, &mut proxy_elapsed).await;
  // after do_handle() req.headers() may be empty.. we are not using here so it is fine.
  let elapsed = instant.elapsed().as_nanos() as f64 / 1000000.0;
  let status = res.status().as_u16();
  let path = req.uri().path();
  if proxy_elapsed == 0.0 {
    proxy_elapsed = elapsed;
  }
  let method = req.method();
  info!("{method} {path} {status} Proxy took {proxy_elapsed:.3}ms, total:{elapsed:.3}ms");
  Ok(res)
}

#[inline]
async fn do_handle(req: &mut Request<Body>, elapsed: &mut f64) -> Response<Body> {
  let instant = std::time::Instant::now();
  let path = req.uri().path();
  let service = match CONFIG.services.iter().find(|s| path.starts_with(&s.path)) {
    Some(service) => service,
    None => return response::not_found("Not Found".into()),
  };
  if CONFIG.enable_auth {
    let Some(claims) = auth::is_authenticated(req) else {
      return response::forbidden("A valid auth token is expected".into());
    };
    if !service.ratelimit.is_within_limit(&DEFAULT_RATELIMIT_KEY) {
      return response::too_many_requests("Service Rate Limit Error".into());
    } else if !service.ratelimit_session.is_within_limit(&claims.sub) {
      return response::too_many_requests("Session Rate Limit Error".into());
    }
  } else if !service.ratelimit.is_within_limit(&DEFAULT_RATELIMIT_KEY) {
    return response::too_many_requests("Service Rate Limit Error".into());
  }
  let bytes = match hyper::body::to_bytes(req.body_mut()).await {
    Ok(bytes) => bytes,
    Err(_err) => return response::bad_request("Error while reading body".into()),
  };
  let body_str = match std::str::from_utf8(&bytes) {
    Ok(bytes) => bytes,
    Err(_utf8_err) => return response::bad_request("Invalid body encoding".into()),
  };
  if !body_str.is_empty() {
    let value: QueryObject = match serde_json::from_str(body_str) {
      Ok(value) => value,
      Err(err) => return response::bad_request(format!("Error invalid body {err:?}").into()),
    };

    let query = match Query::new(&value.query, &SCHEMA, service) {
      Ok(query) => query,
      Err(err) => return response::bad_request(format!("Error processing body {err:?}").into()),
    };
    // info!("query: {query}");
    if query.has_depth_limit_exceeded(CONFIG.max_depth) {
      return response::bad_request("Depth Limit Error".into());
    }
    if service.max_allowed_cost > 0 {
      let _cost = match query.calculate_cost() {
        Ok(cost) if cost > service.max_allowed_cost => {
          return response::bad_request("Cost Exceeded".into())
        }
        Ok(cost) => cost,
        Err(err) => return response::bad_request(format!("Error calculating cost {err:?}").into()),
      };
    }
  }
  *elapsed = instant.elapsed().as_nanos() as f64 / 1000000.0;
  let mut res = do_forwarding(req, body_str, &service.upstream_endpoint).await;
  for _ in 1..service.upstream_retry_count {
    if res.status() == StatusCode::OK {
      break;
    }
    res = do_forwarding(req, body_str, &service.upstream_endpoint).await;
  }
  if res.status() != StatusCode::OK {
    if let Some(endpoint) = &service.failover_endpoint {
      return do_forwarding(req, body_str, endpoint).await;
    }
  }
  res
}

#[inline]
async fn do_forwarding(req: &Request<Body>, body: &str, endpoint: &str) -> Response<Body> {
  let path = req.uri().path();
  let uri = match req.uri().query() {
    Some(query) => format!("{endpoint}{path}&{query}").parse(),
    None => format!("{endpoint}{path}").parse(),
  };
  let uri: Uri = match uri {
    Ok(uri) => uri,
    Err(err) => return response::bad_request(format!("Invalid uri {err:?}").into()),
  };
  let mut proxy_req = hyper::Request::new(body.to_owned().into());
  *proxy_req.uri_mut() = uri;
  *proxy_req.method_mut() = req.method().clone();
  *proxy_req.headers_mut() = req.headers().to_owned();
  // info!("upstream uri {uri:?}");
  tokio::select! {
    res = CLIENT.request(proxy_req) => match res {
      Ok(res) => res,
      Err(_err) => {
        // info!("error {_err}");
        response::bad_gateway("Bad Gateway".into())
      }
    },
    _ = tokio::time::sleep(Duration::from_secs(CONFIG.upstream_timeout_sec)) => {
      info!("Timed out waiting for response from upstream endpoint {endpoint}");
      response::gateway_timeout("Timed out waiting for response from upstream endpoint".into())
    }
  }
}

#[derive(Deserialize)]
struct QueryObject<'a> {
  query: Cow<'a, str>,
}

mod auth;
mod client;
mod ratelimit;
mod response;
