/**
Response codes
Author: Kiran Sahoo
Date: May 1, 2023
*/
use hyper::{Body, Response, StatusCode};

#[inline]
pub fn bad_request(body: Body) -> Response<Body> {
  response(StatusCode::BAD_REQUEST, body)
}

#[inline]
pub fn bad_gateway(body: Body) -> Response<Body> {
  response(StatusCode::BAD_GATEWAY, body)
}

#[inline]
pub fn gateway_timeout(body: Body) -> Response<Body> {
  response(StatusCode::GATEWAY_TIMEOUT, body)
}

#[inline]
pub fn not_found(body: Body) -> Response<Body> {
  response(StatusCode::NOT_FOUND, body)
}

#[inline]
#[allow(unused)]
pub fn ok(body: Body) -> Response<Body> {
  Response::new(body)
}

#[inline]
pub fn forbidden(body: Body) -> Response<Body> {
  response(StatusCode::FORBIDDEN, body)
}

#[inline]
pub fn too_many_requests(body: Body) -> Response<Body> {
  response(StatusCode::TOO_MANY_REQUESTS, body)
}

#[inline]
fn response(status: StatusCode, body: Body) -> Response<Body> {
  let mut response = Response::new(body);
  *response.status_mut() = status;
  response
}
