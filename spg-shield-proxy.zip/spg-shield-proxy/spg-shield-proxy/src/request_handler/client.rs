use hyper::{client::HttpConnector, Client};
use once_cell::sync::Lazy;

pub static CLIENT: Lazy<Client<HttpConnector>> = Lazy::new(Client::new);
