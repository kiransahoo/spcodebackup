/**
Provides both Key and Non key Rate Limiting
Author: Kiran Sahoo
Date: May 1, 2023
*/
use crate::config::RateLimit;

pub trait IsWithinLimit {
  #[allow(clippy::needless_borrow)]
  #[allow(clippy::ptr_arg)]
  fn is_within_limit(&self, key: &String) -> bool;
}

impl IsWithinLimit for Option<RateLimit> {
  #[inline]
  fn is_within_limit(&self, key: &String) -> bool {
    match &self {
      None => true,
      Some(r) => match r.check_key(key) {
        Ok(()) => true,
        Err(_not_until) => false,
      },
    }
  }
}
