/**
JWT Authentication 
Author: Kiran Sahoo
Date: April 30, 2023
*/
use hyper::{header::AUTHORIZATION, Body, Request};
use once_cell::sync::Lazy;
use serde::{Deserialize, Serialize};

use hmac::{digest::KeyInit, Hmac};
use jwt::VerifyWithKey;
use sha2::Sha256;

use crate::config::CONFIG;

#[derive(Debug, Serialize, Deserialize)]
pub struct Claims {
  pub aud: String,
  pub sub: String,
  pub exp: usize,
}
pub static JWT_KEY: Lazy<Hmac<Sha256>> =
  Lazy::new(|| Hmac::new_from_slice(CONFIG.secret_key.as_bytes()).unwrap());

#[inline]
pub fn is_authenticated(req: &Request<Body>) -> Option<Claims> {
  let token = match req.headers().get(AUTHORIZATION).map(|h| h.to_str()) {
    Some(Ok(token)) => token.trim_start_matches("Bearer "),
    _other => return None,
  };
  match token.verify_with_key(&*JWT_KEY) {
    Ok(claims) => Some(claims),
    Err(_err) => {
      info!("bad token {_err:?}");
      None
    }
  }
}
