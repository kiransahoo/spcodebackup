/**
Main Code that Uses Hyper Tokio
Author: Kiran Sahoo
Date: May 1, 2023
*/
#[macro_use]
extern crate log;
use std::net::SocketAddr;

use args::ARGS;
use config::CONFIG;

use hyper::server::conn::Http;
use hyper::service::service_fn;

use std::io::Write;
use tokio::net::{TcpListener, TcpStream};
use tokio::spawn;
mod config;

#[inline]
async fn handle_stream(stream: TcpStream) {
  let service = service_fn(request_handler::handle);
  if let Err(err) = Http::new().serve_connection(stream, service).await {
    info!("Error serving connection: {err:?}");
  }
}

async fn server_loop() -> anyhow::Result<()> {
  let listener = TcpListener::bind(SocketAddr::from(([0, 0, 0, 0], CONFIG.port))).await?;
  info!("Listening on {:?}", listener.local_addr());
  loop {
    let (stream, _socket_addr) = listener.accept().await?;
    spawn(handle_stream(stream));
  }
}
pub fn main() {
  env_logger::builder()
    .filter(Some(env!("CARGO_BIN_NAME")), ARGS.log_level)
    .format(|buf, record| {
      let file = record.file().unwrap_or("unknown");
      let line = record.line().unwrap_or(0);
      let level = record.level();
      let args = record.args();
      match file.starts_with("src/") {
        true => writeln!(buf, "{file}:{line} {level} : {args}"),
        false => Ok(()),
      }
    })
    .init();
  CONFIG.init();
  request_handler::init();
  //let mut rt = tokio::runtime::Builder::new_current_thread();
  let mut rt = tokio::runtime::Builder::new_multi_thread();

  let rt = rt
    .enable_all()
    .build()
    .expect("Failed to create tokio runtime");
  if let Err(err) = rt.block_on(server_loop()) {
    error!("error while running {err:?}");
  }
}

mod args;
mod graphql;
mod request_handler;
