use clap::Parser;
use log::LevelFilter;
use once_cell::sync::Lazy;

#[derive(Parser, Debug)]
#[command(author, version, about, long_about = None)]
pub struct Args {
  /// Path to config.yaml file
  #[arg(short, long)]
  pub config: String,
  /// Path to schema.graphql file
  #[arg(short, long)]
  pub schema: String,
  /// off,error,warn,info,debug,trace
  #[arg(long, default_value = "info")]
  pub log_level: LevelFilter,
}

pub static ARGS: Lazy<Args> = Lazy::new(Args::parse);
