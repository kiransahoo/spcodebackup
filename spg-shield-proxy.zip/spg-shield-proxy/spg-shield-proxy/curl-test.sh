#!/bin/sh
QUERY='{"query":"query { constituents }"}'
# QUERY='query {
#         articles_1(limit: 3) {
#           id
#           news {
#             id
#           }
#         }
#         articles_2(limit: 6) {
#           id
#           news {
#             id
#           }
#         }
#       }'
# QUERY='query {
#         articles {
#           news {
#             article {
#               news {
#                 article {
#                   id
                
#                 }
#               }
#             }
#           }
#         }
#       }'
# QUERY='{
#           parents(limit: 2, names: ["elon", "foo"]) {
#             name
#             children(limit: 4) {
#               name
#             }
#           }
#         }'
# QUERY='query {
#         field
#         default
#       }'
# QUERY='query {
#   category(id: "1") {
#     id
#     name
#     subcategories {
#       id
#       name
#       subcategories {
#         id
#         name
#         subcategories {
#           id
#           name
#         }
#       }
#     }
#   }
# }'
# QUERY='{
#   pipelines {
#     deals {
#       pipeline {
#         deals {
#           pipeline {
#             id
#           }
#         }
#       }
#     }
#   }
# }'

curl -X POST 127.0.0.1:8081 \
  -H 'Authorization: Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiIiLCJzdWIiOiJtZSIsImV4cCI6MH0.41l_w0ADr1or25o-JvBMb4og4mF-nUolVtCTC7__7nI' \
  -H 'X-REQUEST-TYPE: GraphQL' \
  -H 'Content-Type: application/json' \
  -d "$QUERY" -v

