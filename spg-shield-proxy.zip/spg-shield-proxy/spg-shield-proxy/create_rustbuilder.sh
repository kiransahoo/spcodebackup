#!/bin/sh
a="/$0"
a="${a%/*}"
a="${a:-.}"
a="${a##/}/"
BINDIR=$(
  cd "$a"
  pwd
)

DEBIAN_VERSION="bullseye"
IMAGE="rust:slim-$DEBIAN_VERSION"
NAME=rustbuilder
USER=$(whoami)
EXEC="docker exec ${NAME}"
docker container rm ${NAME} --force
docker run -itd --name ${NAME} \
  --hostname ${NAME} \
  -v /:/host \
  $IMAGE /bin/sh
$EXEC useradd $USER
# $EXEC usermod -a -G sudo $USER
